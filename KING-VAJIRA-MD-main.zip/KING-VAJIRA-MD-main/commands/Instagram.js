/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：１．０．１                                                // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail Tech Info
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo0
   * @description : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.2
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/








//     const _0x5b99a6=_0x46c1;function _0x46c1(_0x5713cc,_0xb2c5bf){const _0x2ecdc1=_0x2ecd();return _0x46c1=function(_0x46c1a9,_0x517e8d){_0x46c1a9=_0x46c1a9-0x137;let _0x5bf361=_0x2ecdc1[_0x46c1a9];return _0x5bf361;},_0x46c1(_0x5713cc,_0xb2c5bf);}(function(_0x5d3a0d,_0x235ab1){const _0xe400d3=_0x46c1,_0x21360b=_0x5d3a0d();while(!![]){try{const _0x8c5f43=-parseInt(_0xe400d3(0x14e))/0x1+parseInt(_0xe400d3(0x141))/0x2*(-parseInt(_0xe400d3(0x140))/0x3)+-parseInt(_0xe400d3(0x13e))/0x4*(parseInt(_0xe400d3(0x145))/0x5)+parseInt(_0xe400d3(0x13a))/0x6+-parseInt(_0xe400d3(0x154))/0x7+parseInt(_0xe400d3(0x144))/0x8+parseInt(_0xe400d3(0x13b))/0x9*(parseInt(_0xe400d3(0x13f))/0xa);if(_0x8c5f43===_0x235ab1)break;else _0x21360b['push'](_0x21360b['shift']());}catch(_0x4b3806){_0x21360b['push'](_0x21360b['shift']());}}}(_0x2ecd,0x4b810));const {Insta,smd,Config,prefix}=require(_0x5b99a6(0x149));smd({'pattern':_0x5b99a6(0x146),'alias':['ig'],'desc':_0x5b99a6(0x137),'category':_0x5b99a6(0x13c),'filename':__filename},async(_0x56d24b,_0x57a2c6,_0x17c6ce,{isCreator:_0x3a0d54})=>{const _0x3cfc63=_0x5b99a6;if(!_0x17c6ce)return _0x57a2c6['reply'](_0x3cfc63(0x143));try{let _0x3bc6b7=await Insta(_0x17c6ce);console[_0x3cfc63(0x14c)](_0x3cfc63(0x151),_0x3bc6b7);for(let _0x4b61b4=0x0;_0x4b61b4<_0x3bc6b7[_0x3cfc63(0x152)];_0x4b61b4++){await _0x56d24b[_0x3cfc63(0x138)]['sendFileUrl'](_0x57a2c6[_0x3cfc63(0x14d)],_0x3bc6b7[_0x4b61b4],_0x3cfc63(0x14f)+Config[_0x3cfc63(0x153)]);}}catch(_0x317e50){return await _0x57a2c6[_0x3cfc63(0x142)](_0x317e50);}}),smd({'pattern':'ig','desc':'Downloads\x20Instagram\x20videos.','category':'downloader','filename':__filename,'use':_0x5b99a6(0x150)},async(_0x4661e6,_0x3c8b60,_0x3fa41c)=>{const _0x5ced15=_0x5b99a6;if(!_0x3fa41c||!_0x3fa41c[_0x5ced15(0x139)]('https://'))return await _0x3c8b60['send'](_0x5ced15(0x13d)+prefix+_0x5ced15(0x147));try{const _0x1a8e01=require(_0x5ced15(0x14b));let _0x159ed7=await _0x1a8e01[_0x5ced15(0x14a)](_0x3fa41c);console[_0x5ced15(0x14c)]('insta\x20:\x20',_0x159ed7);for(let _0x17915f=0x0;_0x17915f<_0x159ed7[_0x5ced15(0x152)];_0x17915f++){await _0x4661e6['bot'][_0x5ced15(0x148)](_0x3c8b60['chat'],_0x159ed7[_0x17915f],Config[_0x5ced15(0x153)]);}}catch(_0x4130a3){return await _0x3c8b60[_0x5ced15(0x142)](_0x4130a3),console['log']('error\x20while\x20insta\x20Downloading\x20:\x20',_0x4130a3);}});function _0x2ecd(){const _0x4ee41a=['insta\x20:\x20','length','caption','946834cOFSKv','download\x20instagram\x20post.','bot','startsWith','2714160NCyOlE','9VvAqpw','downloader','*_Please\x20Give\x20me\x20Insta\x20Video\x20Url_*\x0a*Example\x20_','4XjKaBE','5307170AxUeoM','3KgiTRi','518426WhCANE','error','Need\x20post\x20url.','4506424DgdYXQ','1735445JoqCcg','insta','insta2\x20https://www.instagram.com/reel/Cmvj5aWJE56/?utm_source=ig_web_copy_link_*','sendFileUrl','../lib','instagram','mumaker','log','chat','495552FwLARQ','*Downloaded\x20Media\x20from\x20instagram.*','<add\x20insta\x20url.>'];_0x2ecd=function(){return _0x4ee41a;};return _0x2ecd();}